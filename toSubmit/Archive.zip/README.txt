Michael Chen
CS446
Analysis Questions:

Q1:
The average length of a story in the collction is 1215 words. The shortest document is 4 words. The longest document is 26139 words.

Q2:
The most frequently appearing word is 'the' with an appearance in 966 stories. The most frequently used word is also the word 'the', being used 96151 times.

Q3:
There are a total of 27217 unique words. Of these words, 10056 appear only a single time. This accounts for roughly 36.75%.

Q4:
If we were to consider the top 100 documents from both queries, and we were to remove the duplicates, there would be a total of 100 documents to consider still.
If we were to consider the top 20 documents from both queries, and we were to remove all duplicates, there would be a total of 30 documents to consider.
If we were only able to judge a total of 25 documents, then we would only be able to consider the top 15 documents from both queries.